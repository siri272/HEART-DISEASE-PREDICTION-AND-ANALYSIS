class InputUserInfo:
    def __init__(self, sex, chest_pain_type, peak_exercise_st_segment, thalium_test):
        self.sex = sex
        self.chest_pain = chest_pain_type
        self.peak_slope = peak_exercise_st_segment
        self.thalassemia = thalium_test

    def convert(self):
        if self.sex == 'male':
            self.sex = 1
        elif self.sex == 'female':
            self.sex = 0
        if self.chest_pain == 'TYPICAL ANGINA':
            self.chest_pain = 0
        elif self.chest_pain == 'ATYPICAL ANGINA':
            self.chest_pain = 1
        elif self.chest_pain == 'TYPICAL ANGINA':
            self.chest_pain = 2
        elif self.chest_pain == 'ASYMPTOMATIC ANGINA':
            self.chest_pain = 3
        if self.peak_slope == 'FLAT':
            self.peak_slope = 0
        elif self.peak_slope == 'DOWNSLOPING':
            self.peak_slope = 1
        elif self.peak_slope == 'UPSLOPING':
            self.peak_slope = 2

        if self.thalassemia == 'normal or fixed defect':
            self.thalassemia = 0
        elif self.thalassemia == 'reversible defect':
            self.thalassemia = 1

        return self.sex, self.chest_pain, self.peak_slope, self.thalassemia
# for testing the module

#sex = 'female'
#chest_pain_type = 'asymptomatic angina'
#peak_exercise_st_segment = 'upsloping'
#thalium_test = 'reversible defect'

#input = InputUesrInfo(sex, chest_pain_type, peak_exercise_st_segment, thalium_test)
#print(input.convert())