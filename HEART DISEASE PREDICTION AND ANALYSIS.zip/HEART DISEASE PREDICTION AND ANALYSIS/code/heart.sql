

CREATE DATABASE heartdb;
USE heartdb;

CREATE TABLE `user` (
    `name` VARCHAR(100),
    `phone` VARCHAR(10),
    `email` VARCHAR(100) PRIMARY KEY,
    `password` VARCHAR(16)
);

INSERT INTO `user` (`name`,`phone`, `email`, `password`) VALUES
    ('john','1023456789', 'john@gmail.com', '123456');





