const tipImages = document.querySelectorAll('.tip-image');
        const tipDescriptions = document.querySelectorAll('.tip-description');

        tipImages.forEach((img, index) => {
            img.addEventListener('mouseover', () => {
                tipDescriptions[index].style.display = 'block';
                tipDescriptions[index].style.left = `${img.offsetLeft + img.offsetWidth + 10}px`;
                tipDescriptions[index].style.top = `${img.offsetTop}px`;
            });
            img.addEventListener('mouseout', () => {
                tipDescriptions[index].style.display = 'none';
            });
        });

        // Add smooth scroll and fade-in animation on page load
        window.addEventListener('load', () => {
            const elements = document.querySelectorAll('.opacity-0');
            elements.forEach(element => {
                element.classList.remove('opacity-0', 'translate-y-10');
            });
        });